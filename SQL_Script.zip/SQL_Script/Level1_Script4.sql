-- Identify the most common pizza size ordered.

SELECT 
    pizzas.size AS Most_Ordered_Size,
    COUNT(order_details.order_details_id) AS Total_Count
FROM
    pizzas
        JOIN
    order_details ON pizzas.pizza_id = order_details.pizza_id
GROUP BY Most_Ordered_Size
ORDER BY Total_Count DESC
LIMIT 1