-- List the top 5 most ordered pizza types along with their quantities.

SELECT 
    pizza_types.name AS Top_5_Pizzas_Ordered,
    SUM(order_details.quantity) AS Ordered_Quantity
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    order_details ON order_details.pizza_id = pizzas.pizza_id
GROUP BY Top_5_Pizzas_Ordered
ORDER BY Ordered_Quantity DESC
LIMIT 5