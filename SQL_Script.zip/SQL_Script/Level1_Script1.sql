-- Retrieve the total number of orders placed.

select count(order_id) as Total_orders_Pleaced from orders;